﻿using System.Data;
using Microsoft.Data.SqlClient;
using Npgsql;

namespace SimpleAdo.DataLayer
{
    public static class DatabaseFactory
    {
        public static IDbConnection CreateConnection(string providerType, string connectionString)
        {
            return providerType switch
            {
                "SqlServer" => new SqlConnection(connectionString),
                "Postgres" => new NpgsqlConnection(connectionString),
                _ => throw new NotSupportedException($"Database provider '{providerType}' is not supported")
            };
        }

        public static IDbDataParameter CreateParameter(string providerType, string name, object? value)
        {
            return providerType switch
            {
                "SqlServer" => new SqlParameter(name, value ?? DBNull.Value),
                "Postgres" => new NpgsqlParameter(name, value ?? DBNull.Value),
                _ => throw new NotSupportedException($"Database provider '{providerType}' is not supported")
            };
        }
    }
}