﻿using SimpleAdo.Models;
using System.Data;

namespace SimpleAdo.DataLayer
{
    public class UniversalDataRepository : IDataRepository<User>
    {
        private readonly string _providerType;
        private readonly string _connectionString;
        private readonly ILogger<UniversalDataRepository> _logger;

        public UniversalDataRepository(IConfiguration config, ILogger<UniversalDataRepository> logger)
        {
            _providerType = config["Database:ProviderType"] ?? "SqlServer";
            _connectionString = config["Database:ConnectionString"] ?? throw new ArgumentNullException("ConnectionString");
            _logger = logger;
        }

        private IDbConnection CreateConnection() => DatabaseFactory.CreateConnection(_providerType, _connectionString);

        // All table/column/query logic is in code for each provider!
        private string TableName => _providerType == "Postgres" ? "users" : "Users";
        private string IdCol => _providerType == "Postgres" ? "id" : "Id";
        private string NameCol => _providerType == "Postgres" ? "name" : "Name";
        private string EmailCol => _providerType == "Postgres" ? "email" : "Email";

        public List<User> GetAll()
        {
            var users = new List<User>();
            using var conn = CreateConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {IdCol}, {NameCol}, {EmailCol} FROM {TableName} ORDER BY {IdCol}";

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new User
                {
                    Id = reader.GetInt32(reader.GetOrdinal(IdCol)),
                    Name = reader.GetString(reader.GetOrdinal(NameCol)),
                    Email = reader.GetString(reader.GetOrdinal(EmailCol))
                });
            }
            return users;
        }

        public User? GetById(int id)
        {
            using var conn = CreateConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {IdCol}, {NameCol}, {EmailCol} FROM {TableName} WHERE {IdCol} = @Id";
            cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Id", id));
            using var reader = cmd.ExecuteReader();
            return reader.Read()
                ? new User
                {
                    Id = reader.GetInt32(reader.GetOrdinal(IdCol)),
                    Name = reader.GetString(reader.GetOrdinal(NameCol)),
                    Email = reader.GetString(reader.GetOrdinal(EmailCol))
                } : null;
        }

        public int Create(User user)
        {
            using var conn = CreateConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            if (_providerType == "Postgres")
            {
                cmd.CommandText = $"INSERT INTO {TableName} ({NameCol}, {EmailCol}) VALUES (@Name, @Email) RETURNING {IdCol}";
                cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Name", user.Name));
                cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Email", user.Email));
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            else // SqlServer
            {
                cmd.CommandText = $"INSERT INTO {TableName} ({NameCol}, {EmailCol}) OUTPUT INSERTED.{IdCol} VALUES (@Name, @Email)";
                cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Name", user.Name));
                cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Email", user.Email));
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public bool Update(User user)
        {
            using var conn = CreateConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"UPDATE {TableName} SET {NameCol} = @Name, {EmailCol} = @Email WHERE {IdCol} = @Id";
            cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Id", user.Id));
            cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Name", user.Name));
            cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Email", user.Email));
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool Delete(int id)
        {
            using var conn = CreateConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = $"DELETE FROM {TableName} WHERE {IdCol} = @Id";
            cmd.Parameters.Add(DatabaseFactory.CreateParameter(_providerType, "@Id", id));
            return cmd.ExecuteNonQuery() > 0;
        }
    }
}