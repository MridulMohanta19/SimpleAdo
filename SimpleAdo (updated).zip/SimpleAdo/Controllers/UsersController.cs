﻿using Microsoft.AspNetCore.Mvc;
using SimpleAdo.Models;
using SimpleAdo.DataLayer;

namespace SimpleAdo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IDataRepository<User> _repo;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IDataRepository<User> repo, ILogger<UsersController> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        [HttpGet]
        public ActionResult<List<User>> GetAll()
        {
            try { return Ok(_repo.GetAll()); }
            catch (Exception ex) { _logger.LogError(ex, "Error GetAll"); return StatusCode(500, "Server error."); }
        }

        [HttpGet("{id}")]
        public ActionResult<User> GetById(int id)
        {
            try
            {
                var user = _repo.GetById(id);
                return user == null ? NotFound() : Ok(user);
            }
            catch (Exception ex) { _logger.LogError(ex, "Error GetById"); return StatusCode(500, "Server error."); }
        }

        [HttpPost]
        public ActionResult<User> Create(User user)
        {
            try
            {
                user.Id = _repo.Create(user);
                return CreatedAtAction(nameof(GetById), new { id = user.Id }, user);
            }
            catch (Exception ex) { _logger.LogError(ex, "Error Create"); return StatusCode(500, "Server error."); }
        }

        [HttpPut("{id}")]
        public ActionResult Update(int id, User user)
        {
            try
            {
                if (id != user.Id) return BadRequest("ID mismatch.");
                return _repo.Update(user) ? NoContent() : NotFound();
            }
            catch (Exception ex) { _logger.LogError(ex, "Error Update"); return StatusCode(500, "Server error."); }
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            try { return _repo.Delete(id) ? NoContent() : NotFound(); }
            catch (Exception ex) { _logger.LogError(ex, "Error Delete"); return StatusCode(500, "Server error."); }
        }
    }
}