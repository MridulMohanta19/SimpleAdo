﻿namespace SimpleAdo.Models
{
    public class DatabaseConfig
    {
        public string ProviderType { get; set; } = "";
        public string ConnectionString { get; set; } = "";
    }
}