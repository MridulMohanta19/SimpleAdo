﻿using Microsoft.AspNetCore.Mvc;
using SimpleAdo.DataLayer;
using SimpleAdo.Models;

namespace SimpleAdoNetApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IDataRepository<User> _userRepository;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IDataRepository<User> userRepository, ILogger<UsersController> logger)
        {
            _userRepository = userRepository;
            _logger = logger;
        }

        // GET api/users
        [HttpGet]
        public ActionResult<List<User>> GetAll()
        {
            try
            {
                var users = _userRepository.GetAll();
                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetAll users");
                return StatusCode(500, "Error retrieving users");
            }
        }

        // GET api/users/{id}
        [HttpGet("{id}")]
        public ActionResult<User> GetById(int id)
        {
            try
            {
                if (id <= 0)
                    return BadRequest("Invalid user ID");

                var user = _userRepository.GetById(id);
                if (user == null)
                    return NotFound($"User with ID {id} not found");

                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetById for user {Id}", id);
                return StatusCode(500, "Error retrieving user");
            }
        }

        // POST api/users
        [HttpPost]
        public ActionResult<User> Create([FromBody] User user)
        {
            try
            {
                if (string.IsNullOrEmpty(user.Name) || string.IsNullOrEmpty(user.Email))
                    return BadRequest("Name and Email are required");

                var newId = _userRepository.Create(user);
                user.Id = newId;

                return CreatedAtAction(nameof(GetById), new { id = newId }, user);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Create user");
                return StatusCode(500, "Error creating user");
            }
        }

        // PUT api/users/{id}
        [HttpPut("{id}")]
        public ActionResult Update(int id, [FromBody] User user)
        {
            try
            {
                if (id != user.Id)
                    return BadRequest("ID mismatch");

                if (string.IsNullOrEmpty(user.Name) || string.IsNullOrEmpty(user.Email))
                    return BadRequest("Name and Email are required");

                var success = _userRepository.Update(user);
                if (!success)
                    return NotFound($"User with ID {id} not found");

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Update user {Id}", id);
                return StatusCode(500, "Error updating user");
            }
        }

        // DELETE api/users/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            try
            {
                if (id <= 0)
                    return BadRequest("Invalid user ID");

                var success = _userRepository.Delete(id);
                if (!success)
                    return NotFound($"User with ID {id} not found");

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Delete user {Id}", id);
                return StatusCode(500, "Error deleting user");
            }
        }
    }
}