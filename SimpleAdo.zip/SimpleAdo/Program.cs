using SimpleAdo.DataLayer;
using SimpleAdo.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure database settings
builder.Services.Configure<DatabaseSettings>(
    builder.Configuration.GetSection("DatabaseSettings"));

// Register data repository
builder.Services.AddScoped<IDataRepository<User>>(serviceProvider =>
{
    var logger = serviceProvider.GetRequiredService<ILogger<UniversalDataRepository>>();
    var configuration = builder.Configuration;

    var databaseSettings = new DatabaseSettings();
    configuration.GetSection("DatabaseSettings").Bind(databaseSettings);

    if (!databaseSettings.Providers.TryGetValue(databaseSettings.ActiveProvider, out var providerConfig))
    {
        throw new InvalidOperationException($"Database provider '{databaseSettings.ActiveProvider}' not found in configuration");
    }

    return new UniversalDataRepository(providerConfig, logger);
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();