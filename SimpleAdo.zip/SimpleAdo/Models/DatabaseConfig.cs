﻿namespace SimpleAdo.Models
{
    public class DatabaseProviderConfig
    {
        public string ConnectionString { get; set; } = "";
        public string ProviderType { get; set; } = "";
        public string TableName { get; set; } = "";
        public Dictionary<string, string> Columns { get; set; } = new();
        public Dictionary<string, string> Queries { get; set; } = new();
    }

    public class DatabaseSettings
    {
        public string ActiveProvider { get; set; } = "";
        public Dictionary<string, DatabaseProviderConfig> Providers { get; set; } = new();
    }
}