﻿using SimpleAdo.Models;
using System.Data;
namespace SimpleAdo.DataLayer
{
    public class UniversalDataRepository : IDataRepository<User>
    {
        private readonly DatabaseProviderConfig _config;
        private readonly ILogger<UniversalDataRepository> _logger;

        public UniversalDataRepository(DatabaseProviderConfig config, ILogger<UniversalDataRepository> logger)
        {
            _config = config;
            _logger = logger;
        }

        private string ProcessQuery(string queryTemplate)
        {
            return queryTemplate
                .Replace("{TableName}", _config.TableName)
                .Replace("{Id}", _config.Columns["Id"])
                .Replace("{Name}", _config.Columns["Name"])
                .Replace("{Email}", _config.Columns["Email"]);
        }

        private User MapToUser(IDataReader reader)
        {
            var idColumn = _config.Columns["Id"];
            var nameColumn = _config.Columns["Name"];
            var emailColumn = _config.Columns["Email"];

            return new User
            {
                Id = reader.GetInt32(reader.GetOrdinal(idColumn)),
                Name = reader.GetString(reader.GetOrdinal(nameColumn)),
                Email = reader.GetString(reader.GetOrdinal(emailColumn))
            };
        }

        public List<User> GetAll()
        {
            var users = new List<User>();

            try
            {
                using var connection = DatabaseFactory.CreateConnection(_config.ProviderType, _config.ConnectionString);
                connection.Open();

                var sql = ProcessQuery(_config.Queries["SelectAll"]);
                using var command = connection.CreateCommand();
                command.CommandText = sql;

                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    users.Add(MapToUser(reader));
                }

                _logger.LogInformation("Retrieved {Count} users using {Provider}", users.Count, _config.ProviderType);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all users");
                throw;
            }

            return users;
        }

        public User? GetById(int id)
        {
            try
            {
                using var connection = DatabaseFactory.CreateConnection(_config.ProviderType, _config.ConnectionString);
                connection.Open();

                var sql = ProcessQuery(_config.Queries["SelectById"]);
                using var command = connection.CreateCommand();
                command.CommandText = sql;
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Id", id));

                using var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    var user = MapToUser(reader);
                    _logger.LogInformation("Retrieved user {Id} using {Provider}", id, _config.ProviderType);
                    return user;
                }

                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user {Id}", id);
                throw;
            }
        }

        public int Create(User user)
        {
            try
            {
                using var connection = DatabaseFactory.CreateConnection(_config.ProviderType, _config.ConnectionString);
                connection.Open();

                var sql = ProcessQuery(_config.Queries["Insert"]);
                using var command = connection.CreateCommand();
                command.CommandText = sql;
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Name", user.Name));
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Email", user.Email));

                var result = command.ExecuteScalar();
                var newId = Convert.ToInt32(result);

                _logger.LogInformation("Created user with ID {Id} using {Provider}", newId, _config.ProviderType);
                return newId;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating user");
                throw;
            }
        }

        public bool Update(User user)
        {
            try
            {
                using var connection = DatabaseFactory.CreateConnection(_config.ProviderType, _config.ConnectionString);
                connection.Open();

                var sql = ProcessQuery(_config.Queries["Update"]);
                using var command = connection.CreateCommand();
                command.CommandText = sql;
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Id", user.Id));
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Name", user.Name));
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Email", user.Email));

                var rowsAffected = command.ExecuteNonQuery();
                var success = rowsAffected > 0;

                _logger.LogInformation("Updated user {Id}: {Success} using {Provider}", user.Id, success, _config.ProviderType);
                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user {Id}", user.Id);
                throw;
            }
        }

        public bool Delete(int id)
        {
            try
            {
                using var connection = DatabaseFactory.CreateConnection(_config.ProviderType, _config.ConnectionString);
                connection.Open();

                var sql = ProcessQuery(_config.Queries["Delete"]);
                using var command = connection.CreateCommand();
                command.CommandText = sql;
                command.Parameters.Add(DatabaseFactory.CreateParameter(_config.ProviderType, "@Id", id));

                var rowsAffected = command.ExecuteNonQuery();
                var success = rowsAffected > 0;

                _logger.LogInformation("Deleted user {Id}: {Success} using {Provider}", id, success, _config.ProviderType);
                return success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting user {Id}", id);
                throw;
            }
        }
    }
}
