﻿using System.Data;
using Microsoft.Data.SqlClient;
using Npgsql;
using MySql.Data.MySqlClient;
using Microsoft.Data.Sqlite;

namespace SimpleAdo.DataLayer
{
    public static class DatabaseFactory
    {
        public static IDbConnection CreateConnection(string providerType, string connectionString)
        {
            return providerType switch
            {
                "SqlServer" => new SqlConnection(connectionString),
                "Postgres" => new NpgsqlConnection(connectionString),
                "MySql" => new MySqlConnection(connectionString),
                "SQLite" => new SqliteConnection(connectionString),
                _ => throw new NotSupportedException($"Database provider '{providerType}' is not supported")
            };
        }

        public static IDbDataParameter CreateParameter(string providerType, string name, object? value)
        {
            return providerType switch
            {
                "SqlServer" => new SqlParameter(name, value ?? DBNull.Value),
                "Postgres" => new NpgsqlParameter(name, value ?? DBNull.Value),
                "MySql" => new MySqlParameter(name, value ?? DBNull.Value),
                "SQLite" => new SqliteParameter(name, value ?? DBNull.Value),
                _ => throw new NotSupportedException($"Database provider '{providerType}' is not supported")
            };
        }
    }
}