﻿namespace SimpleAdo.DataLayer
{
    public interface IDataRepository<T>
    {
        List<T> GetAll();
        T? GetById(int id);
        int Create(T entity);
        bool Update(T entity);
        bool Delete(int id);
    }
}